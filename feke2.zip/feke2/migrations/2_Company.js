const Company = artifacts.require("Company");

module.exports = function(deployer, network, accounts) {
    // Assuming the owner of the contract is the first account
    const ownerAddress = accounts[0];
    deployer.deploy(Company, ownerAddress);
};
