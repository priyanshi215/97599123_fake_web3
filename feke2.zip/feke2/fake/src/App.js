
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Web3 from 'web3';
import { useEffect, useState } from 'react';
//import metamaskSDK from "@web3-onboard/metamask";
//import logo from './logo.svg';
//import './App.css';
import Navigation from './components/Navigation';
//import  Navigation  from './components/Navi';

import Home from './components/Home';
import VerifyProduct from './components/VerifyProduct';
import AddProduct from './components/AddProduct';
import GetContract from './components/GetContract';

import contractABI from './contracts/Company.json';

// Config
import config from './contracts/Central.json';
import DeployContract from './components/DeployContract';

function App() {

  const [provider, setProvider] = useState(null);
  const [contract, setcontract] = useState(null);

  const [contract2, setcontract2] = useState(null);
  

  useEffect(() => {
    const provider = new Web3.providers.HttpProvider("HTTP://127.0.0.1:7545");

    async function Hello() {
        const web3 = new Web3(provider);
        const networkId = await web3.eth.net.getId();
        const deployedNetwork = contractABI.networks[networkId];
        const deployedNetwork2 = config.networks[networkId];
        console.log(deployedNetwork.address);
        console.log(deployedNetwork2.address);
       
        const contract = new web3.eth.Contract(contractABI.abi, deployedNetwork.address);
        const contract2 = new web3.eth.Contract(config.abi, deployedNetwork2.address);
        setProvider({provider:provider});
        setcontract2({contract:contract});
        setcontract(contract => {
            // calculation using currentcontract
            return contract;
            //provider&& Hello();
        });

       /* useEffect(()=>{
          const{contract} =provider;
          async function readData(){
            const data = await contract.methods.addProducts().call();
            console.log(data);
          }
          contract&& readData();
        },[provider]
      );*/
          
        console.log(contract);
        console.log(contract2);

        
    }

    provider && Hello();
}, [contract]); // Include contract in the dependency array


  
  //hello();
  return (
    <div className="App">
      <Router>
        <Navigation contract2={contract2} provider={provider} contract={contract} setcontract2={setcontract2} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/createcontract" element={<DeployContract contract2={contract2} provider={provider} contract={contract} />} />
          <Route path="/getcontract" element={<GetContract contract2={contract2} provider={provider} contract={contract} />} />
          <Route path="/addproduct" element={<AddProduct contract2={contract2} provider={provider} contract={contract} />} />
          <Route path="/verify" element={<VerifyProduct contract2={contract2} provider={provider} contract={contract} />} />
        </Routes>
      </Router>
    </div>
  );
  

}


export default App;
